text = "CHIRAGBHAGAT"

