import math
def encrypt_keyless_transposition(str):
    temp1=""
    temp2=""
    for i in range(0,len(str)):
        if i%2==0:
            temp1+=str[i].upper()
        else:
            temp2+=str[i].upper()
    return temp1+temp2
def decrypt_keyless_transposition(str):
    decrypted_text=""
    str=str.upper()
    mid=math.ceil(len(str)/2)
    print("mid---->",mid)
    for i in range(0,mid):
        # print("i+mid---->",i+mid)
        # print("str length-->",len(str))
        if i+mid<len(str):
            decrypted_text+=str[i]+str[mid+i]
            print(decrypted_text)
        else:
            decrypted_text+=str[i]
    return decrypted_text


str=input("Enter Plaintext : ")
str=str.replace(" ","")
encrypted=encrypt_keyless_transposition(str)
decrypted=decrypt_keyless_transposition(encrypted)
print("Encrypted text:",encrypted)
print("Decrypted text:",decrypted)