text = "CHIRAG"
shift = 3
encr = ""
for i in text:
    a = ord(i) - 65
    a = (a+shift)%26
    encr += str(chr(a + 65))

print(encr)

decr=""
for j in encr:
    b = ord(j) - 65
    b = (b-shift)%26
    decr += str(chr(b+65))

print(decr)




