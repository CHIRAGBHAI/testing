import numpy as np

key = input("Key: ")
key = key.upper()
t_key = ''
for i in key:
	if i not in t_key: t_key+=i

ltbl = [[0 for _ in range(5)] for _ in range(5)]
c = flag = 0
for i in range(5):
	for j in range(5):
		ltbl[i][j] = t_key[c]; c+=1
		if c>=len(t_key): flag = 1; break
	if flag: break

def ispst(ch):
	for i in range(5):
		for j in range(5):
			if ltbl[i][j] == ch: return True
	return False

c%=5
ch = 65
if c!=0:
	while c!=5:
		if not ispst(chr(ch)):
			if ch==73 and not ispst(chr(74)):
				ltbl[i][j+1] = chr(ch); ch+=1; c+=1; j+=1
			elif ch == 74 and not ispst(chr(ch-1)):
				ltbl[i][j+1] = chr(ch); ch+=1; c+=1; j+=1
			else: ltbl[i][j+1] = chr(ch); ch+=1; c+=1; j+=1
		else: ch+=1

for i in range(i+1, 5):
	c = 0
	j = 0
	while j<5:	
		if not ispst(chr(ch)):
			if ch==73 and ispst(chr(74)): ch+=1; continue
			elif ch == 74 and ispst(chr(ch-1)): ch+=1; continue
			else: ltbl[i][j] = chr(ch); ch+=1; c+=1; j+=1
		else: ch+=1

msg = input("Message: ").upper()
t_msg = ''
for i in msg:
	if len(t_msg)!=0 and t_msg[-1] == i: t_msg+='X'
	t_msg+=i
if len(t_msg)&1: t_msg+='Z'

# print(ltbl, t_msg)

ct = ''
for i in range(0,len(t_msg),2):
	x,y = t_msg[i], t_msg[i+1]
	temp = [0,0]
	for i in range(5):
		for j in range(5):
			if ltbl[i][j] == x: temp[0] = (i,j)
			elif ltbl[i][j] == y: temp[1] = (i,j)
	if temp[0][0] == temp[1][0]: ct+=ltbl[temp[0][0]][(temp[0][1]+1)%5]+ltbl[temp[0][0]][(temp[1][1]+1)%5]
	elif temp[0][1] == temp[1][1]: ct+=ltbl[(temp[0][0]+1)%5][temp[0][1]]+ltbl[(temp[1][0]+1)%5][temp[0][1]]
	else:
		i = 1
		while (temp[0][1]+i)%5 != temp[1][1]: i+=1
		ct+=ltbl[temp[0][0]][(temp[0][1]+i)%5]
		i = 1
		while (temp[0][0]+i)%5 != temp[1][0]: i+=1
		ct+=ltbl[(temp[0][0]+i)%5][temp[0][1]]

print('Lookup Table:')
print(np.array(ltbl).reshape(5,5))
print('Processed Input:', t_msg)
print('Encrypted Message:', ct)