import math
import random

def prime_number(num):
    for j in range(2,num//2):
        if num%j==0:
            return False
    return True

def modInverse(a,m):
    for i in range(1,m):
        if (((a%m) * (i%m)) % m == 1):
            return i

M=(input("Enter Plaintext (M) : "))
try:
    M=int(M)
except:
    M=M.upper()
if type(M)!=int:
    Ascii_conversion=""
    for char in M:
        Ascii_conversion+=str(ord(char))
    M=Ascii_conversion
    print("M----->",M)
prime_numbers=[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]
p=prime_numbers[random.randint(0,len(prime_numbers)-1)]
print("p------>",p)
q=0
i=p+1
while q==0:
    if prime_number(i)==True:
        if (p*i)>int(M):
            q=i
            print("q--->",q)
            break
    i+=1
n=p*q

Euler_Totient_Function=(p-1)*(q-1)
e=2
while(math.gcd(e,Euler_Totient_Function)!=1):
    e+=1
print("Public Key Pair : ({},{})".format(e,n))
d=modInverse(e,Euler_Totient_Function)
print("Private Key Pair : ({},{})".format(d,n))
Encrypted_Text=(int(M)**e)%n
print("Encrypted_Message : {}".format(Encrypted_Text))
Decrypted_Text=(Encrypted_Text**d)%n
if type(M)!=int:
    Decrypted_Ascii=str(Decrypted_Text)
    Decrypted_Text=""
    for i in range(0,len(Decrypted_Ascii),2):
        Decrypted_Text+=chr(int(Decrypted_Ascii[i]+Decrypted_Ascii[i+1]))

print("Decrypted_Message : {}".format(Decrypted_Text))