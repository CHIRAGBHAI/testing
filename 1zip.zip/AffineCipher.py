text = "THISISANEXERCISE"

km=15
kp=20

encr=""
for i in text:
    a = ord(i)-65
    a = ((a*km) + kp)%26
    encr += str(chr(a+65))

print(encr)


decr=""
m_l = 0

for j in range(1,26):
    if ((km%26) * (j%26))%26 == 1:
        m_l = j

for k in encr:
    d = ord(k) - 65
    d = ((d - kp) * m_l)%26
    decr+=str(chr(d+65))

print(decr)