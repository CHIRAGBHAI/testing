text = "CHIRAG"
key = 3
encr = ""
for i in text:
    a = ord(i) - 65
    a = (a*key)%26
    encr+=str(chr(a + 65))

print(encr)

def multiplicative_cipher(b):
    for k in range(1,26):
        if (((b%26 * k%26)%26) == 1):
            return k

decr = ""
m_inv = multiplicative_cipher(key)
for j in encr:
    b = ord(j) - 65
    b = (b*m_inv)%26
    decr += str(chr(b+65))

print(decr)